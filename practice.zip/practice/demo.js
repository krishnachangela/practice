function validation() {
	var email = document.forms["reg_form"]["email"].value,
		 password = document.forms["reg_form"]["password"].value,
		 gender = document.forms["reg_form"]["gender"].value,
		 sc = document.forms["reg_form"]["sc"].value,
		 check = document.forms["reg_form"]["check"].value,
	     email1 = /^[a-zA-Z0-9_\.\-]+\@[a-zA-Z0-9\-]+\.[a-zA-Z]{2,4}$/;
	     password1 = /[a-z]/;



	    /*if(email == "" || email == NULL){
	    	alert("enter the email address");
	    	return false;
	    }*/
	    if(email1.test(email) == 0){
	    	alert("enter valid email");
	    	return false;
  		}
		if(password1.test(password) == 0){
			alert("enter valid password");
			return false;
		}

	    if(password.length<8){
	    	alert("enter the required password");
	    	return false;
	    }
	    if(gender == "" || gender == NULL){
	    	alert("enter the gender");
	    	return false;
	    }
	    if (sc == "") {
	    	alert("enter the course");
	    	return false;
	    }
	    if (check == "") {
	    	alert("enter your ans");
	    	return false;
	    }


}