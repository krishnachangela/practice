
<?php
require_once("db.php");

if(isset($_POST['submit']))
{
  if (empty($_POST["email"]))
  {
    echo "you didn't enter the email";
  }
  elseif (empty($_POST["password"])) {
    echo "you didn't enter the password";
  }
  elseif (empty($_POST["gender"])) {
      echo "you didn't enter the gender";
  }
  elseif (empty($_POST["sc"])) {
      echo "you didn't enter the select subject";
  }
  /*elseif (empty($_POST["check"])) {
       echo "you didn't enter the checkbox";
  }*/
  else{
      $email = $password = $gender = $sc = $check = "";
     
      $email = $_POST['email'];
      $password = $_POST['password'];
      $gender = $_POST['gender'];
      $sc = $_POST['sc'];
      $check = $_POST['check'];
      
    $query = "INSERT INTO user (`email`, `password`, `gender`, `sc`, `check`) VALUES ('$email', '$password', '$gender', '$sc', '$check')";


    $result = mysqli_query($conn, $query);
        if($result)
        {
          echo "successfully entered";
        }
    }

}

?>
